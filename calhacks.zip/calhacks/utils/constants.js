export const DEFAULT_DECK_LIST = ['SD1', 'SD2']

export const TODO_FILE_NAME = 'fs_todo_list.txt'
